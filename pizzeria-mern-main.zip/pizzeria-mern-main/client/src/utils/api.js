export const API_ENDPOINT = "/api"
